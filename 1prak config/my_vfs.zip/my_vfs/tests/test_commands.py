from emulator.commands import CommandHandler

def test_ls():
    handler = CommandHandler("", None)
    assert handler.ls() is None
