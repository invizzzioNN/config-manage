import argparse
import os
import zipfile
from emulator.commands import CommandHandler
from emulator.logger import Logger

def main():
    parser = argparse.ArgumentParser(description="Эмулятор UNIX shell.")
    parser.add_argument("--user", required=True, help="Имя пользователя.")
    parser.add_argument("--vfs", required=True, help="Путь к zip-архиву виртуальной файловой системы.")
    parser.add_argument("--log", required=True, help="Путь к log-файлу.")
    parser.add_argument("--script", help="Путь к стартовому скрипту.", default=None)

    args = parser.parse_args()

    # Проверяем, что файл zip существует
    if not os.path.exists(args.vfs):
        print(f"Ошибка: файл {args.vfs} не найден.")
        return

    # Проверяем лог
    logger = Logger(args.log)

    # Инициализация команды
    handler = CommandHandler(args.vfs, logger)

    # Запуск команд из скрипта, если указан
    if args.script:
        if not os.path.exists(args.script):
            print(f"Ошибка: скрипт {args.script} не найден.")
            return
        with open(args.script, "r") as script_file:
            for line in script_file:
                handler.execute(line.strip())
    else:
        # Ручной ввод команд
        print(f"Добро пожаловать, {args.user}!")
        while True:
            command = input(f"{args.user}@emulator$ ")
            if command.strip() == "exit":
                print("Выход из эмулятора.")
                break
            handler.execute(command.strip())

if __name__ == "__main__":
    main()
