import csv

class Logger:
    def __init__(self, log_path):
        self.log_path = log_path

    def log(self, command):
        with open(self.log_path, "a", newline="") as log_file:
            writer = csv.writer(log_file)
            writer.writerow([command])
