import os
import zipfile
import time

class CommandHandler:
    def __init__(self, vfs_path, logger):
        self.vfs_path = vfs_path
        self.logger = logger
        self.cwd = "/"

    def execute(self, command):
        self.logger.log(command)
        parts = command.split()
        cmd = parts[0]

        if cmd == "ls":
            self.ls()
        elif cmd == "cd":
            if len(parts) < 2:
                print("Ошибка: укажите путь.")
            else:
                self.cd(parts[1])
        elif cmd == "uniq":
            print("uniq не реализована.")
        elif cmd == "uptime":
            print(f"Система работает: {time.time()} секунд.")
        else:
            print(f"Команда {cmd} не найдена.")

    def ls(self):
        print("Команда ls выполнена (симуляция).")

    def cd(self, path):
        print(f"Перешли в директорию {path} (симуляция).")
